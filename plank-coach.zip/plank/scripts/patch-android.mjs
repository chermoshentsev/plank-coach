// Доводит сгенерированный `cap add android` проект: разрешения, экран не гаснет, иконки, тёмный сплэш.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const app = path.join(root, 'android', 'app', 'src', 'main');
const cfg = JSON.parse(fs.readFileSync(path.join(root, 'capacitor.config.json'), 'utf8'));
if (!fs.existsSync(app)) { console.error('Нет папки android/. Сначала: npx cap add android'); process.exit(1); }

// 1) Разрешения
const mf = path.join(app, 'AndroidManifest.xml');
let xml = fs.readFileSync(mf, 'utf8');
const add = [
  '<uses-permission android:name="android.permission.CAMERA" />',
  '<uses-permission android:name="android.permission.VIBRATE" />',
  '<uses-feature android:name="android.hardware.camera" android:required="false" />',
  '<uses-feature android:name="android.hardware.camera.front" android:required="false" />',
].filter((l) => !xml.includes(l.match(/android:name="([^"]+)"/)[1] + '"'));
if (add.length) xml = xml.replace('</manifest>', '    ' + add.join('\n    ') + '\n</manifest>');
fs.writeFileSync(mf, xml);

// 2) MainActivity: экран не гаснет во время тренировки
const pkgDir = path.join(app, 'java', ...cfg.appId.split('.'));
fs.mkdirSync(pkgDir, { recursive: true });
fs.writeFileSync(path.join(pkgDir, 'MainActivity.java'), `package ${cfg.appId};

import android.os.Bundle;
import android.view.WindowManager;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }
}
`);

// 3) Иконки
const over = path.join(root, 'android-overrides');
const res = path.join(app, 'res');
const copyDir = (from, to) => {
  for (const e of fs.readdirSync(from, { withFileTypes: true })) {
    const a = path.join(from, e.name), b = path.join(to, e.name);
    if (e.isDirectory()) { fs.mkdirSync(b, { recursive: true }); copyDir(a, b); } else fs.copyFileSync(a, b);
  }
};
copyDir(path.join(over, 'res'), res);

// фон адаптивной иконки
const bgXml = path.join(res, 'values', 'ic_launcher_background.xml');
fs.mkdirSync(path.dirname(bgXml), { recursive: true });
fs.writeFileSync(bgXml, `<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <color name="ic_launcher_background">#0A0F1E</color>\n</resources>\n`);

// 4) Тёмный сплэш вместо белого
const walk = (d) => fs.readdirSync(d, { withFileTypes: true }).flatMap((e) => e.isDirectory() ? walk(path.join(d, e.name)) : [path.join(d, e.name)]);
for (const f of walk(res)) if (path.basename(f) === 'splash.png') fs.copyFileSync(path.join(over, 'splash.png'), f);

console.log('Android-проект подготовлен: разрешения, иконки, keep-screen-on.');

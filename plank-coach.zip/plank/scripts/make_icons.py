"""Генерирует иконки приложения (PWA + Android). Запуск: python3 scripts/make_icons.py"""
import os
from PIL import Image, ImageDraw, ImageFilter

BG = (10, 15, 30)
MINT = (55, 242, 165)
CYAN = (59, 201, 255)

def lerp(a, b, t): return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))

def figure(size, scale=1.0, bg=True):
    """Рисует «планку»-скелет: линия тела с тремя суставами."""
    S = size * 4  # суперсэмплинг
    img = Image.new('RGBA', (S, S), (0, 0, 0, 0))
    if bg:
        d = ImageDraw.Draw(img)
        d.rounded_rectangle([0, 0, S, S], radius=int(S * 0.22), fill=BG + (255,))
        # мягкое свечение
        glow = Image.new('RGBA', (S, S), (0, 0, 0, 0))
        gd = ImageDraw.Draw(glow)
        gd.ellipse([S * .15, S * .1, S * .95, S * .8], fill=(59, 201, 255, 50))
        img = Image.alpha_composite(img, glow.filter(ImageFilter.GaussianBlur(S * .08)))
    # геометрия внутри безопасной зоны
    cx, cy = S / 2, S / 2
    k = scale * S
    p_feet = (cx - 0.31 * k, cy + 0.09 * k)
    p_hip = (cx - 0.02 * k, cy + 0.0 * k)
    p_sh = (cx + 0.27 * k, cy - 0.07 * k)
    p_head = (cx + 0.37 * k, cy - 0.15 * k)
    lw = int(0.075 * k)
    layer = Image.new('RGBA', (S, S), (0, 0, 0, 0))
    # градиентная линия: рисуем сегментами
    steps = 60
    pts = [p_feet, p_hip, p_sh]
    d = ImageDraw.Draw(layer)
    def seg(a, b, t0, t1):
        for i in range(steps):
            u0, u1 = i / steps, (i + 1) / steps
            x0, y0 = a[0] + (b[0]-a[0])*u0, a[1] + (b[1]-a[1])*u0
            x1, y1 = a[0] + (b[0]-a[0])*u1, a[1] + (b[1]-a[1])*u1
            c = lerp(MINT, CYAN, t0 + (t1-t0)*(u0+u1)/2)
            d.line([x0, y0, x1, y1], fill=c + (255,), width=lw)
            d.ellipse([x1-lw/2, y1-lw/2, x1+lw/2, y1+lw/2], fill=c + (255,))
    seg(p_feet, p_hip, 0.0, 0.5)
    seg(p_hip, p_sh, 0.5, 1.0)
    # руки-опора
    d.line([p_sh[0], p_sh[1], p_sh[0], p_sh[1] + 0.2 * k], fill=CYAN + (255,), width=int(lw * .8))
    # голова и суставы
    r = int(0.075 * k)
    d.ellipse([p_head[0]-r, p_head[1]-r, p_head[0]+r, p_head[1]+r], fill=CYAN + (255,))
    for p, col in ((p_hip, lerp(MINT, CYAN, .5)), (p_feet, MINT)):
        rr = int(0.062 * k)
        d.ellipse([p[0]-rr, p[1]-rr, p[0]+rr, p[1]+rr], fill=(255, 255, 255, 255), outline=col + (255,), width=int(rr*.5))
    # пол
    fy = cy + 0.29 * k
    d.line([cx - 0.42 * k, fy, cx + 0.42 * k, fy], fill=(60, 75, 120, 255), width=int(lw * .45))
    out = Image.alpha_composite(img, layer)
    return out.resize((size, size), Image.LANCZOS)

def save(img, path):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    img.save(path)

root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
# PWA
save(figure(192, 0.95), f'{root}/www/icons/icon-192.png')
save(figure(512, 0.95), f'{root}/www/icons/icon-512.png')
mk = figure(512, 0.62, bg=False)
bgimg = Image.new('RGBA', (512, 512), BG + (255,)); bgimg.alpha_composite(mk)
save(bgimg, f'{root}/www/icons/icon-maskable-512.png')

# Android: legacy launcher + adaptive foreground
dens = {'mdpi': (48, 108), 'hdpi': (72, 162), 'xhdpi': (96, 216), 'xxhdpi': (144, 324), 'xxxhdpi': (192, 432)}
for name, (l, f) in dens.items():
    base = f'{root}/android-overrides/res/mipmap-{name}'
    ic = figure(l, 0.95)
    save(ic, f'{base}/ic_launcher.png')
    # круглая версия
    m = Image.new('L', (l*4, l*4), 0); ImageDraw.Draw(m).ellipse([0, 0, l*4-1, l*4-1], fill=255)
    m = m.resize((l, l), Image.LANCZOS)
    rd = Image.new('RGBA', (l, l), (0, 0, 0, 0)); rd.paste(figure(l, 0.8), (0, 0), m)
    save(rd, f'{base}/ic_launcher_round.png')
    save(figure(f, 0.60, bg=False), f'{base}/ic_launcher_foreground.png')

# Сплэш: сплошной тёмный фон (растягивается без искажений)
sp = Image.new('RGB', (16, 16), BG)
save(sp, f'{root}/android-overrides/splash.png')
print('icons ok')

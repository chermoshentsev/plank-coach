// Копирует офлайн-модель и wasm MediaPipe Pose из node_modules в www/mediapipe.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const src = path.join(root, 'node_modules', '@mediapipe', 'pose');
const dst = path.join(root, 'www', 'mediapipe');

if (!fs.existsSync(src)) {
  console.error('Не найден node_modules/@mediapipe/pose — сначала выполните: npm install');
  process.exit(1);
}
fs.rmSync(dst, { recursive: true, force: true });
fs.mkdirSync(dst, { recursive: true });

const skip = (f) => /\.(d\.ts|md|json|map)$/i.test(f) || /^LICENSE/i.test(f) || /heavy/i.test(f); // heavy-модель слишком тяжёлая для телефона
let total = 0;
for (const f of fs.readdirSync(src)) {
  const p = path.join(src, f);
  if (!fs.statSync(p).isFile() || skip(f)) continue;
  fs.copyFileSync(p, path.join(dst, f));
  total += fs.statSync(p).size;
}
const need = ['pose.js', 'pose_web.binarypb', 'pose_landmark_full.tflite', 'pose_solution_packed_assets.data'];
const missing = need.filter((f) => !fs.existsSync(path.join(dst, f)));
if (missing.length) { console.error('Не хватает файлов MediaPipe:', missing.join(', ')); process.exit(1); }
console.log(`MediaPipe Pose скопирован в www/mediapipe (${(total / 1048576).toFixed(1)} МБ)`);

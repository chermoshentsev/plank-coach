import assert from 'node:assert/strict';
import { analyzePlank, IssueTracker, SessionStats, LM } from '../www/js/analysis.js';

const frame = { frameW: 1280, frameH: 720 };

// Синтетическая планка на предплечьях, вид сбоку. facing=+1 — голова справа.
function plank({ facing = 1, hipDev = 0, elbowDx = 0, earUp = 25, kneeBend = 0, high = false, hideLeft = false } = {}) {
  const A = { x: 200, y: 520 }, S = { x: 880, y: 440 };
  const L = Math.hypot(S.x - A.x, S.y - A.y);
  const pt = (t) => ({ x: S.x + (A.x - S.x) * t, y: S.y + (A.y - S.y) * t });
  const ux = (S.x - A.x) / L, uy = (S.y - A.y) / L;         // от стоп к плечу
  let n = { x: -uy, y: ux }; if (n.y > 0) n = { x: -n.x, y: -n.y }; // вверх
  const H0 = pt(0.38);
  const H = { x: H0.x + n.x * hipDev * L, y: H0.y + n.y * hipDev * L };
  const K0 = pt(0.7), K = { x: K0.x + n.x * kneeBend * L, y: K0.y + n.y * kneeBend * L };
  const E = high ? { x: S.x + elbowDx, y: S.y + 100 } : { x: S.x + elbowDx, y: S.y + 95 };
  const W = high ? { x: E.x + elbowDx * 0, y: E.y + 95 } : { x: E.x + 100, y: E.y };
  const Ear = { x: S.x + 60, y: S.y - earUp };
  const pts = new Array(33).fill(null).map(() => ({ x: 0, y: 0, v: 0 }));
  const set = (i, q, v = 0.95) => { pts[i] = { x: q.x, y: q.y, v }; };
  const sides = [['L', 0.95], ['R', hideLeft ? 0.95 : 0.7]];
  for (const [s, v] of sides) {
    const off = s === 'L' ? 0 : 1;
    set(LM.SH_L + off, S, v); set(LM.EL_L + off, E, v); set(LM.WR_L + off, W, v);
    set(LM.HIP_L + off, H, v); set(LM.KN_L + off, K, v); set(LM.AN_L + off, A, v); set(LM.EAR_L + off, Ear, v);
  }
  if (hideLeft) for (const i of [LM.SH_L, LM.EL_L, LM.WR_L, LM.HIP_L, LM.KN_L, LM.AN_L, LM.EAR_L]) pts[i].v = 0.05;
  if (facing === -1) for (const q of pts) q.x = 1280 - q.x;
  return pts;
}
const ids = (r) => r.issues.map((i) => i.id);

// Идеальная планка
let r = analyzePlank(plank(), frame);
assert.ok(r.detected && r.inPosition, 'должна быть в позиции');
assert.deepEqual(ids(r), [], 'идеальная планка без замечаний: ' + ids(r));
assert.equal(r.mode, 'forearm');

// Провисший таз
r = analyzePlank(plank({ hipDev: -0.1 }), frame);
assert.equal(r.issues[0].id, 'sagHip'); assert.equal(r.issues[0].sev, 2);
r = analyzePlank(plank({ hipDev: -0.05 }), frame);
assert.equal(r.issues[0].id, 'sagHip'); assert.equal(r.issues[0].sev, 1);

// Задранный таз
r = analyzePlank(plank({ hipDev: 0.1 }), frame);
assert.equal(r.issues[0].id, 'pikeHip'); assert.equal(r.issues[0].sev, 2);

// Локти впереди / позади плеч (голова справа → «вперёд» = вправо)
r = analyzePlank(plank({ elbowDx: 60 }), frame);
assert.ok(ids(r).includes('armsFwd'), 'armsFwd: ' + ids(r));
r = analyzePlank(plank({ elbowDx: -60 }), frame);
assert.ok(ids(r).includes('armsBack'), 'armsBack: ' + ids(r));

// Голова опущена / задрана
r = analyzePlank(plank({ earUp: -80 }), frame);
assert.ok(ids(r).includes('headDown'), 'headDown: ' + ids(r));
r = analyzePlank(plank({ earUp: 200 }), frame);
assert.ok(ids(r).includes('headUp'), 'headUp: ' + ids(r));

// Колени
r = analyzePlank(plank({ kneeBend: -0.07 }), frame);
assert.ok(ids(r).includes('bentKnees'), 'knees: ' + ids(r));

// Зеркальность: голова слева — те же результаты
for (const cfg of [{ hipDev: -0.1 }, { elbowDx: 60 }, { hipDev: 0.1 }]) {
  const a = ids(analyzePlank(plank(cfg), frame));
  const b = ids(analyzePlank(plank({ ...cfg, facing: -1 }), frame));
  assert.deepEqual(a, b, 'зеркально: ' + JSON.stringify(cfg));
}

// Выбор видимой стороны
r = analyzePlank(plank({ hideLeft: true }), frame);
assert.equal(r.side, 'R'); assert.ok(r.detected);

// Высокая планка с прямыми руками
r = analyzePlank(plank({ high: true }), frame);
assert.equal(r.mode, 'high'); assert.deepEqual(ids(r), [], 'high: ' + ids(r));

// Стоя — не планка
const stand = plank();
for (const q of stand) { const { x, y } = q; q.x = 640 + (y - 480) * 0.1; q.y = 100 + (1280 - x) * 0.5; }
r = analyzePlank(stand, frame);
assert.equal(r.inPosition, false);

// Строгость
const mild = plank({ hipDev: -0.06 });
assert.equal(analyzePlank(mild, frame, ).issues.length > 0, true);
assert.equal(analyzePlank(mild, { ...frame, strict: 1.5 }).issues.filter((i) => i.id === 'sagHip').length, 0);

// Антидребезг (кадры каждые 100 мс)
const t = new IssueTracker(600, 400);
let now = 0;
const bad = [{ id: 'sagHip', sev: 2 }];
const run = (issues, ms) => { let r; for (let i = 0; i < ms / 100; i++) { now += 100; r = t.update(issues, now); } return r; };
t.update(bad, now);
assert.equal(run(bad, 300).size, 0, 'ещё рано');
assert.equal(run(bad, 400).size, 1, 'включилась');
assert.equal(run([], 200).size, 1, 'не гаснет сразу');
assert.equal(run([], 300).size, 0, 'погасла');
run([], 500);
assert.equal(run(bad, 300).size, 0, 'короткая вспышка не засчитана');
assert.equal(run([], 500).size, 0);

// Статистика
const st = new SessionStats();
st.add(6, new Map()); st.add(2, new Map([['sagHip', 1]])); st.add(2, new Map([['sagHip', 2], ['headDown', 1]]));
assert.equal(st.total, 10);
assert.equal(st.score, Math.round(100 * (6 + 0.6 * 2 + 0.15 * 2) / 10));
assert.equal(st.top()[0].id, 'sagHip');

console.log('Все тесты пройдены ✔');

// Звуковые сигналы (WebAudio), вибрация и голосовые подсказки.
let ctx = null;

export function unlock() {
  try {
    ctx = ctx || new (window.AudioContext || window.webkitAudioContext)();
    if (ctx.state === 'suspended') ctx.resume();
  } catch { /* звука нет — не страшно */ }
}

function tone(freq, start, dur, { vol = 0.5, type = 'sine' } = {}) {
  if (!ctx) return;
  const t0 = ctx.currentTime + start;
  const osc = ctx.createOscillator();
  const g = ctx.createGain();
  osc.type = type;
  osc.frequency.value = freq;
  g.gain.setValueAtTime(0.0001, t0);
  g.gain.exponentialRampToValueAtTime(vol, t0 + 0.012);
  g.gain.setValueAtTime(vol, t0 + Math.max(0.02, dur - 0.05));
  g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
  osc.connect(g).connect(ctx.destination);
  osc.start(t0);
  osc.stop(t0 + dur + 0.02);
}

export const vibrate = (p) => { try { navigator.vibrate && navigator.vibrate(p); } catch { /* ignore */ } };

export const sounds = {
  tick()  { tone(760, 0, 0.1, { vol: 0.35 }); },
  go()    { tone(1175, 0, 0.35, { vol: 0.5 }); vibrate(120); },
  warn()  { tone(330, 0, 0.12, { vol: 0.3, type: 'triangle' }); },
  // Финальный сигнал: три коротких писка и один длинный
  finish() {
    [0, 0.32, 0.64].forEach((s) => tone(1568, s, 0.2, { vol: 0.6, type: 'square' }));
    tone(2093, 1.0, 0.8, { vol: 0.6, type: 'square' });
    vibrate([250, 100, 250, 100, 250, 150, 700]);
  },
};

let lastSpeak = 0;
export function speak(text, { force = false, gapMs = 3500 } = {}) {
  const now = performance.now();
  if (!force && now - lastSpeak < gapMs) return false;
  try {
    const synth = window.speechSynthesis;
    if (!synth) return false;
    synth.cancel();
    const u = new SpeechSynthesisUtterance(text);
    u.lang = 'ru-RU';
    u.rate = 1.05;
    synth.speak(u);
    lastSpeak = now;
    return true;
  } catch { return false; }
}
export const stopSpeaking = () => { try { window.speechSynthesis && window.speechSynthesis.cancel(); } catch { /* ignore */ } };

import { analyzePlank, IssueTracker, SessionStats, ISSUES, STRICTNESS } from './analysis.js';
import { makeView, drawVideo, drawSkeleton } from './render.js';
import * as audio from './audio.js';
import { sounds, speak, stopSpeaking, vibrate } from './audio.js';
import { TIPS, GENERAL, headline } from './tips.js';
import { loadSettings, saveSettings, loadHistory, addHistory, summarize } from './storage.js';

const $ = (id) => document.getElementById(id);
const PREP_MS = 10000;          // время, чтобы занять позицию
const HOLD_START_MS = 700;      // сколько держать позу, чтобы стартовал таймер
const POS_GRACE_MS = 1200;      // допустимая потеря позы до паузы
const PRESETS = [30, 45, 60, 90, 120, 180, 300];
const RING_C = 2 * Math.PI * 86;

const settings = loadSettings();
const S = {
  phase: 'idle',                // idle | loading | prep | wait | run | done
  screen: 'home',
  duration: settings.duration,
  prepEnd: 0, remaining: 0, paused: false,
  res: null, active: new Map(),
  lastInPos: 0, inPosSince: 0, cleanSince: 0,
  lastSaid: null, lastSaidAt: 0, needPraise: false, lastWarnBeep: 0,
  cues: {}, lastPrepNum: -1, lastTickNum: -1,
  stats: new SessionStats(), tracker: new IssueTracker(),
  lastTick: 0, running: false, stream: null, wake: null,
};

// ---------- утилиты ----------
const fmt = (s) => { s = Math.max(0, Math.round(s)); return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`; };
const fmtChip = (s) => (s < 60 ? `${s} с` : fmt(s));
function toast(msg, ms = 2400) {
  const t = $('toast'); t.textContent = msg; t.classList.add('show');
  clearTimeout(toast.id); toast.id = setTimeout(() => t.classList.remove('show'), ms);
}
function show(name, push = true) {
  document.querySelectorAll('.screen').forEach((el) => el.classList.toggle('active', el.id === name));
  S.screen = name;
  if (push && name !== 'home') { try { history.pushState({ s: name }, ''); } catch { /* ignore */ } }
}
const snd = (name) => { if (settings.sound) sounds[name](); };

// ---------- главный экран ----------
function renderHome() {
  $('homeTime').textContent = fmt(S.duration);
  const ring = $('homeRing');
  ring.style.strokeDasharray = RING_C;
  ring.style.strokeDashoffset = RING_C * (1 - Math.min(1, S.duration / 300));
  document.querySelectorAll('#presets .chip').forEach((c) => c.classList.toggle('on', Number(c.dataset.s) === S.duration));
  $('setVoice').checked = settings.voice; $('setSound').checked = settings.sound; $('setPause').checked = settings.autoPause;
  document.querySelectorAll('.seg').forEach((seg) => seg.querySelectorAll('button').forEach((b) => b.classList.toggle('on', b.dataset.v === settings[seg.dataset.key])));
  $('camMute').textContent = settings.sound ? '🔊' : '🔇';

  const h = loadHistory(); const sm = summarize(h);
  $('stBest').textContent = sm.best ? fmt(sm.best) : '—';
  $('stCount').textContent = sm.count; $('stStreak').textContent = sm.streak;
  $('historyCard').hidden = !h.length;
  $('historyList').innerHTML = h.slice(0, 5).map((e) => {
    const d = new Date(e.t);
    const when = d.toLocaleDateString('ru-RU', { day: 'numeric', month: 'short' }) + ', ' + d.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' });
    const tone = e.score >= 75 ? 'ok' : e.score >= 55 ? 'warn' : 'bad';
    return `<div class="hist"><div><div class="t">${fmt(e.held)} <span class="when">из ${fmt(e.target)}</span></div><div class="when">${when}</div></div><div class="badge ${tone}">${e.score}</div></div>`;
  }).join('');
}
function setDuration(s) {
  S.duration = Math.max(10, Math.min(600, s));
  settings.duration = S.duration; saveSettings(settings); renderHome();
}
function initHome() {
  $('presets').innerHTML = PRESETS.map((s) => `<button class="chip" data-s="${s}">${fmtChip(s)}</button>`).join('');
  $('presets').addEventListener('click', (e) => { const b = e.target.closest('.chip'); if (b) setDuration(Number(b.dataset.s)); });
  $('durMinus').onclick = () => setDuration(S.duration - (S.duration > 60 ? 10 : 5));
  $('durPlus').onclick = () => setDuration(S.duration + (S.duration >= 60 ? 10 : 5));
  $('setVoice').onchange = (e) => { settings.voice = e.target.checked; saveSettings(settings); };
  $('setSound').onchange = (e) => { settings.sound = e.target.checked; saveSettings(settings); renderHome(); };
  $('setPause').onchange = (e) => { settings.autoPause = e.target.checked; saveSettings(settings); };
  document.querySelectorAll('.seg').forEach((seg) => seg.addEventListener('click', (e) => {
    const b = e.target.closest('button'); if (!b) return;
    settings[seg.dataset.key] = b.dataset.v; saveSettings(settings); renderHome();
  }));
  $('startBtn').onclick = startSession;
  renderHome();
}

// ---------- модель позы ----------
let pose = null, poseReady = null, poseBusy = false;
function initPose() {
  if (poseReady) return poseReady;
  poseReady = (async () => {
    if (typeof window.Pose !== 'function') throw new Error('Модель распознавания не найдена (mediapipe/pose.js)');
    const p = new window.Pose({ locateFile: (f) => `mediapipe/${f}` });
    p.setOptions({ modelComplexity: 1, smoothLandmarks: true, enableSegmentation: false, minDetectionConfidence: 0.5, minTrackingConfidence: 0.5 });
    p.onResults(onResults);
    await p.initialize();
    pose = p;
  })();
  poseReady.catch(() => { poseReady = null; });
  return poseReady;
}

// ---------- камера ----------
const video = $('video'), canvas = $('view'), ctx2d = canvas.getContext('2d');
let cw = 0, ch = 0, dpr = 1;
function resizeCanvas() {
  const r = $('cam').getBoundingClientRect();
  dpr = Math.min(window.devicePixelRatio || 1, 2);
  cw = r.width; ch = r.height;
  canvas.width = Math.round(cw * dpr); canvas.height = Math.round(ch * dpr);
}
new ResizeObserver(resizeCanvas).observe($('cam'));

async function startCamera() {
  stopCamera();
  if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) throw Object.assign(new Error('no-api'), { name: 'NoApi' });
  S.stream = await navigator.mediaDevices.getUserMedia({
    video: { facingMode: { ideal: settings.facing }, width: { ideal: 1280 }, height: { ideal: 720 } }, audio: false,
  });
  video.srcObject = S.stream;
  await video.play();
}
function stopCamera() {
  if (S.stream) S.stream.getTracks().forEach((t) => t.stop());
  S.stream = null; video.srcObject = null;
}

async function loopPose() {
  if (S.running) return;
  S.running = true;
  while (S.running) {
    if (pose && video.readyState >= 2 && video.videoWidth) {
      try { await pose.send({ image: video }); } catch (e) { console.warn('pose.send', e); await new Promise((r) => setTimeout(r, 200)); }
    } else {
      await new Promise((r) => setTimeout(r, 50));
    }
    await new Promise((r) => requestAnimationFrame(r));
  }
}

// ---------- кадр ----------
const smooth = [];
function onResults(r) {
  const vw = video.videoWidth, vh = video.videoHeight;
  if (!vw || !cw) return;
  const mirror = settings.facing === 'user';
  const view = makeView(cw, ch, vw, vh, mirror);
  ctx2d.setTransform(dpr, 0, 0, dpr, 0, 0);
  drawVideo(ctx2d, video, view);

  let res = null;
  if (r.poseLandmarks && r.poseLandmarks.length >= 29) {
    r.poseLandmarks.forEach((l, i) => {
      const x = l.x * vw, y = l.y * vh, v = l.visibility ?? 0;
      const p = smooth[i];
      if (!p || v < 0.2) smooth[i] = { x, y, v };
      else { p.x += (x - p.x) * 0.55; p.y += (y - p.y) * 0.55; p.v = v; }
    });
    res = analyzePlank(smooth, { frameW: vw, frameH: vh, mode: settings.mode, strict: STRICTNESS[settings.strict] ?? 1 });
  }
  const now = performance.now();
  S.res = res;
  if (res && res.detected && res.inPosition) {
    S.lastInPos = now;
    if (!S.inPosSince) S.inPosSince = now;
    S.active = S.tracker.update(res.issues, now);
  } else {
    S.inPosSince = 0;
    S.active = S.tracker.update([], now);
  }
  drawSkeleton(ctx2d, view, res, S.active, ISSUES);
}

// ---------- сессия ----------
async function startSession() {
  audio.unlock();
  S.phase = 'loading';
  show('cam');
  resizeCanvas();
  $('camError').hidden = true; $('loading').hidden = false;
  $('loadingText').textContent = 'Включаю камеру…';
  try { await requestWake(); } catch { /* не критично */ }
  try {
    await startCamera();
    $('loadingText').textContent = 'Загружаю модель распознавания…';
    await initPose();
  } catch (e) { return showCamError(e); }
  $('loading').hidden = true;

  S.stats = new SessionStats(); S.tracker.reset(); S.active = new Map(); smooth.length = 0;
  S.remaining = S.duration; S.paused = false; S.cues = {}; S.lastPrepNum = -1; S.lastTickNum = -1;
  S.lastSaid = null; S.needPraise = false; S.cleanSince = 0; S.lastInPos = 0; S.inPosSince = 0;
  S.prepEnd = performance.now() + PREP_MS; S.lastTick = performance.now();
  S.phase = 'prep';
  speak('Займите позицию', { force: true });
  loopPose();
  clearInterval(S.timerId); S.timerId = setInterval(tick, 80);
  tick();
}

function showCamError(e) {
  $('loading').hidden = true;
  let title = 'Что-то пошло не так', text = String(e && e.message || e);
  if (e && (e.name === 'NotAllowedError' || e.name === 'SecurityError')) {
    title = 'Нет доступа к камере';
    text = 'Разрешите приложению использовать камеру: Настройки → Приложения → Планка-тренер → Разрешения → Камера. Затем нажмите «Повторить».';
  } else if (e && (e.name === 'NotFoundError' || e.name === 'OverconstrainedError')) {
    title = 'Камера не найдена'; text = 'Не удалось найти подходящую камеру. Попробуйте переключить камеру на главном экране.';
  } else if (e && e.name === 'NoApi') {
    title = 'Камера недоступна'; text = 'Эта среда не поддерживает доступ к камере. Откройте приложение по HTTPS или установите APK.';
  } else if (/mediapipe|Pose|wasm|model/i.test(text)) {
    title = 'Не загрузилась модель'; text = 'Файлы распознавания позы не найдены или повреждены. ' + text;
  }
  $('errTitle').textContent = title; $('errText').textContent = text;
  $('camError').hidden = false;
  S.phase = 'idle';
}

async function requestWake() {
  if ('wakeLock' in navigator) S.wake = await navigator.wakeLock.request('screen');
}
function releaseWake() { try { S.wake && S.wake.release(); } catch { /* ignore */ } S.wake = null; }

function posOk(now) { return now - S.lastInPos < POS_GRACE_MS; }

function tick() {
  const now = performance.now();
  const dt = Math.min(now - S.lastTick, 250) / 1000; S.lastTick = now;
  const ok = posOk(now);

  if (S.phase === 'prep') {
    const left = S.prepEnd - now;
    const n = Math.ceil(left / 1000);
    if (n !== S.lastPrepNum) { S.lastPrepNum = n; if (n <= 3 && n > 0) snd('tick'); }
    if (left <= 0) { S.phase = 'wait'; }
  }
  if (S.phase === 'wait') {
    if (ok && S.inPosSince && now - S.inPosSince >= HOLD_START_MS) beginRun();
  }
  if (S.phase === 'run') {
    if (settings.autoPause && !ok) {
      S.paused = true;
    } else {
      S.paused = false;
      S.remaining -= dt;
      if (ok) S.stats.add(dt, S.active);
      timeCues();
      voiceCues(now);
      if (S.remaining <= 0) { S.remaining = 0; return finish(false); }
    }
  }
  updateUI(now, ok);
}

function beginRun() {
  S.phase = 'run'; S.paused = false;
  snd('go');
  speak('Поехали', { force: true });
}

function timeCues() {
  const r = S.remaining, d = S.duration;
  const c = S.cues;
  if (d >= 40 && !c.half && r <= d / 2) { c.half = true; if (settings.voice) speak('Половина времени', { gapMs: 1500 }); }
  if (d > 25 && !c.ten && r <= 10) { c.ten = true; if (settings.voice) speak('Десять секунд', { gapMs: 1500 }); }
  const n = Math.ceil(r);
  if (n <= 3 && n > 0 && n !== S.lastTickNum) { S.lastTickNum = n; snd('tick'); }
}

function voiceCues(now) {
  const top = [...S.active.entries()].sort((a, b) => b[1] - a[1])[0];
  if (top) {
    S.cleanSince = 0;
    const id = top[0];
    if (id !== S.lastSaid || now - S.lastSaidAt > 8000) {
      if (settings.voice) {
        if (speak(ISSUES[id].voice, { gapMs: 3500 })) { S.lastSaid = id; S.lastSaidAt = now; S.needPraise = true; }
      } else if (settings.sound && now - S.lastWarnBeep > 4000) {
        sounds.warn(); S.lastWarnBeep = now; S.lastSaid = id; S.lastSaidAt = now;
      }
    }
  } else {
    if (!S.cleanSince) S.cleanSince = now;
    if (S.needPraise && settings.voice && now - S.cleanSince > 1500) {
      if (speak('Отлично, так держать', { gapMs: 2000 })) { S.needPraise = false; S.lastSaid = null; }
    }
  }
}

function pillState() {
  const r = S.res;
  if (!r || !r.detected) return { tone: 'warn', icon: '👁', text: 'Не вижу вас целиком — отодвиньте телефон, чтобы был виден весь корпус' };
  if (!r.inPosition) return { tone: 'idle', icon: '🧍', text: 'Примите положение планки, боком к камере' };
  const top = [...S.active.entries()].sort((a, b) => b[1] - a[1])[0];
  if (top) return { tone: top[1] >= 2 ? 'bad' : 'warn', icon: top[1] >= 2 ? '⚠️' : '↗', text: ISSUES[top[0]].text };
  return { tone: 'ok', icon: '✓', text: 'Отлично! Держите линию' };
}

function updateUI(now, ok) {
  // таймер
  const showLeft = S.phase === 'run' || S.phase === 'done' ? S.remaining : S.duration;
  $('timerBig').textContent = fmt(Math.ceil(showLeft));
  $('timerBar').style.width = `${S.phase === 'run' ? (1 - S.remaining / S.duration) * 100 : 0}%`;
  $('timerLabel').textContent = S.phase === 'prep' ? 'подготовка' : S.phase === 'wait' ? 'ждём позу' : S.paused ? 'пауза' : 'осталось';

  // центр
  const c = $('center'), big = $('centerBig'), txt = $('centerText');
  if (S.phase === 'prep') {
    c.hidden = false; big.className = 'center-big';
    const n = Math.max(1, Math.ceil((S.prepEnd - now) / 1000));
    if (big.textContent !== String(n)) { big.textContent = n; big.style.animation = 'none'; void big.offsetWidth; big.style.animation = ''; }
    txt.textContent = 'Поставьте телефон сбоку и займите позицию';
  } else if (S.phase === 'wait') {
    c.hidden = false; big.className = 'center-big small'; big.textContent = '🏁';
    txt.textContent = ok ? 'Держите позу…' : 'Встаньте в планку — таймер стартует сам';
  } else if (S.phase === 'run' && S.paused) {
    c.hidden = false; big.className = 'center-big small'; big.textContent = '⏸';
    txt.textContent = 'Пауза — вернитесь в планку';
  } else { c.hidden = true; }

  // подсказка и индикаторы
  const p = pillState();
  $('pill').dataset.tone = p.tone; $('pillIcon').textContent = p.icon; $('pillText').textContent = p.text;
  const groups = S.res && S.res.detected && S.res.inPosition ? S.res.groups : null;
  document.querySelectorAll('.gchip').forEach((el) => {
    const g = el.dataset.g;
    let st = 'idle';
    if (groups) {
      st = groups[g] === 'na' ? 'na' : 'ok';
      for (const [id, sev] of S.active) if (ISSUES[id].group === g) st = sev >= 2 ? 'bad' : (st === 'bad' ? 'bad' : 'warn');
    }
    if (el.dataset.s !== st) el.dataset.s = st;
  });
}

// ---------- завершение ----------
function finish(aborted) {
  if (S.phase === 'done') return;
  S.phase = 'done';
  clearInterval(S.timerId);
  S.running = false;
  stopSpeaking();
  if (!aborted) {
    if (settings.sound) sounds.finish(); else vibrate([250, 100, 250, 100, 600]);
    updateUI(performance.now(), true);
    $('center').hidden = false; $('centerBig').className = 'center-big small'; $('centerBig').textContent = '🎉'; $('centerText').textContent = 'Время вышло!';
    if (settings.voice) setTimeout(() => speak('Время! Отличная работа', { force: true }), settings.sound ? 1900 : 100);
  }
  setTimeout(() => { stopCamera(); releaseWake(); showResult(aborted); }, aborted ? 0 : 2300);
}

function showResult(aborted) {
  const st = S.stats; const held = st.total; const score = st.score;
  const hl = headline(score, held);
  $('resTitle').textContent = aborted ? 'Подход прерван' : hl.title;
  $('resText').textContent = held < 5 ? hl.text : (aborted ? `Вы продержались ${fmt(held)}. ${hl.text}` : hl.text);
  $('scoreNum').textContent = held < 5 ? '—' : score;
  const ring = $('scoreRing'); ring.dataset.tone = hl.tone === 'ok' ? '' : hl.tone;
  ring.style.strokeDasharray = RING_C; ring.style.strokeDashoffset = RING_C;
  requestAnimationFrame(() => requestAnimationFrame(() => { ring.style.strokeDashoffset = RING_C * (1 - (held < 5 ? 0 : score) / 100); }));
  $('resHeld').textContent = fmt(held);
  $('resClean').textContent = held < 5 ? '—' : `${Math.round(st.cleanShare * 100)}%`;
  $('resTarget').textContent = fmt(S.duration);

  const top = st.top(3);
  $('breakdown').hidden = !top.length;
  $('breakdownList').innerHTML = top.map((t) =>
    `<div class="bd"><div class="top"><b>${TIPS[t.id].icon} ${TIPS[t.id].title}</b><span>${Math.round(t.share * 100)}% времени</span></div><div class="track"><i style="width:${Math.min(100, t.share * 100)}%"></i></div></div>`).join('');

  // советы: уникальные по смыслу (armsFwd/armsBack — разные)
  let html = '';
  if (held < 5) {
    html = `<div class="tip"><p>Слишком мало данных для советов. Займите позицию боком к камере и продержитесь подольше.</p></div>`;
  } else {
    if (!top.length) html += `<div class="tip good"><div class="th"><span class="ic">🏆</span>Замечаний нет</div><p>Корпус, руки и шея держались ровно. Чтобы расти дальше — добавьте 10–15 секунд к цели.</p></div>`;
    for (const t of top) {
      const tip = TIPS[t.id];
      html += `<div class="tip"><div class="th"><span class="ic">${tip.icon}</span>${tip.title}</div><p>${tip.why}</p><ul>${tip.fix.map((f) => `<li>${f}</li>`).join('')}</ul></div>`;
    }
    html += `<div class="tip"><div class="th"><span class="ic">💡</span>Совет дня</div><p>${GENERAL[Math.floor(Date.now() / 864e5) % GENERAL.length]}</p></div>`;
  }
  $('tipsList').innerHTML = html;

  if (held >= 5) addHistory({ t: Date.now(), held: Math.round(held), target: S.duration, score });
  renderHome();
  show('result', false);
  $('result').querySelector('.scroll').scrollTop = 0;
}

function closeCam() {
  if (S.phase === 'run' || S.phase === 'wait' || S.phase === 'prep') {
    if (S.stats.total >= 5) return finish(true);
  }
  teardown();
  show('home', false);
}
function teardown() {
  S.running = false; S.phase = 'idle';
  clearInterval(S.timerId); stopSpeaking(); stopCamera(); releaseWake();
}

// ---------- события ----------
function initCam() {
  $('camClose').onclick = () => { history.length > 1 && S.screen !== 'home' ? history.back() : closeCam(); };
  $('camMute').onclick = () => { settings.sound = !settings.sound; saveSettings(settings); renderHome(); toast(settings.sound ? 'Звук включён' : 'Звук выключен'); };
  $('camFlip').onclick = async () => {
    settings.facing = settings.facing === 'user' ? 'environment' : 'user'; saveSettings(settings); renderHome();
    smooth.length = 0; S.tracker.reset();
    try { await startCamera(); toast(settings.facing === 'user' ? 'Фронтальная камера' : 'Основная камера'); } catch (e) { showCamError(e); }
  };
  $('errRetry').onclick = () => { $('camError').hidden = true; startSession(); };
  $('errHome').onclick = () => { teardown(); show('home', false); };
  $('resHome').onclick = () => show('home', false);
  $('resAgain').onclick = () => startSession();
  window.addEventListener('popstate', () => {
    if (S.screen === 'cam') closeCam();
    else if (S.screen === 'result') show('home', false);
  });
  document.addEventListener('visibilitychange', async () => {
    if (!document.hidden && S.screen === 'cam' && S.phase !== 'idle' && S.phase !== 'done') { try { await requestWake(); } catch { /* ignore */ } }
  });
}

initHome();
initCam();
// Прогреваем модель в фоне, чтобы первый старт был быстрым
setTimeout(() => { initPose().catch(() => {}); }, 600);
if ('serviceWorker' in navigator && location.protocol.startsWith('http')) navigator.serviceWorker.register('sw.js').catch(() => {});

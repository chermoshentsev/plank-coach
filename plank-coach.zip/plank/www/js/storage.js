const KEY_SETTINGS = 'plankcoach.settings.v1';
const KEY_HISTORY = 'plankcoach.history.v1';

export const DEFAULTS = {
  duration: 60,      // секунд
  voice: true,       // голосовые подсказки
  sound: true,       // звуковой сигнал
  autoPause: true,   // пауза, если вышли из планки
  mode: 'auto',      // auto | forearm | high
  strict: 'normal',  // soft | normal | strict
  facing: 'user',    // user | environment
};

function read(key, fallback) {
  try { const v = localStorage.getItem(key); return v ? JSON.parse(v) : fallback; } catch { return fallback; }
}
function write(key, value) {
  try { localStorage.setItem(key, JSON.stringify(value)); } catch { /* приватный режим */ }
}

export const loadSettings = () => ({ ...DEFAULTS, ...read(KEY_SETTINGS, {}) });
export const saveSettings = (s) => write(KEY_SETTINGS, s);

export const loadHistory = () => { const h = read(KEY_HISTORY, []); return Array.isArray(h) ? h : []; };
export function addHistory(entry) {
  const h = loadHistory();
  h.unshift(entry);
  write(KEY_HISTORY, h.slice(0, 60));
}

export function summarize(history) {
  const best = history.reduce((m, h) => Math.max(m, h.held || 0), 0);
  const days = new Set(history.map((h) => new Date(h.t).toDateString()));
  let streak = 0;
  const d = new Date();
  if (!days.has(d.toDateString())) d.setDate(d.getDate() - 1); // серия не рвётся, пока день не закончился
  while (days.has(d.toDateString())) { streak++; d.setDate(d.getDate() - 1); }
  return { best, count: history.length, streak };
}

// Чистая логика анализа техники планки. Не зависит от DOM — можно тестировать в Node.
// Все точки — в пикселях кадра: {x, y, v} (v — видимость 0..1). Ось Y направлена вниз.

export const LM = {
  EAR_L: 7, EAR_R: 8,
  SH_L: 11, SH_R: 12, EL_L: 13, EL_R: 14, WR_L: 15, WR_R: 16,
  HIP_L: 23, HIP_R: 24, KN_L: 25, KN_R: 26, AN_L: 27, AN_R: 28,
};

const D2R = Math.PI / 180;
const vec = (a, b) => ({ x: b.x - a.x, y: b.y - a.y });
const dot = (a, b) => a.x * b.x + a.y * b.y;
const len = (a) => Math.hypot(a.x, a.y);
const unit = (a) => { const l = len(a) || 1; return { x: a.x / l, y: a.y / l }; };

/** Угол в точке b (градусы) между лучами b→a и b→c. */
export function angleAt(a, b, c) {
  const u = vec(b, a), w = vec(b, c);
  const l = len(u) * len(w);
  if (!l) return 180;
  return Math.acos(Math.max(-1, Math.min(1, dot(u, w) / l))) / D2R;
}

// Пороги [предупреждение, ошибка]. Для углов — отклонение от идеала.
const BASE = {
  hipSag: [0.045, 0.08],   // доля длины «плечо–лодыжка»
  hipPike: [0.055, 0.09],
  armTilt: [13, 22],       // градусы от вертикали
  elbowDev: [20, 35],      // 180° − угол в локте (высокая планка)
  neckLift: [38, 55],      // голова задрана, градусы от линии корпуса
  neckDrop: [26, 40],      // голова опущена
  kneeDev: [14, 25],       // 180° − угол в колене
};

export const STRICTNESS = { soft: 1.3, normal: 1, strict: 0.75 };

const sev = (value, [warn, bad], k) => (value >= bad * k ? 2 : value >= warn * k ? 1 : 0);

export const ISSUES = {
  sagHip:    { group: 'body',  segs: ['torso', 'thigh'],           text: 'Таз провисает — подтяните пресс и ягодицы', voice: 'Подтяните таз вверх' },
  pikeHip:   { group: 'body',  segs: ['torso', 'thigh'],           text: 'Таз высоко — опустите его на одну линию со спиной', voice: 'Опустите таз' },
  armsFwd:   { group: 'arms',  segs: ['upperArm'],                 text: 'Опора впереди плеч — поставьте её точно под плечи', voice: 'Руки под плечи' },
  armsBack:  { group: 'arms',  segs: ['upperArm'],                 text: 'Опора позади плеч — поставьте её точно под плечи', voice: 'Руки под плечи' },
  bentArms:  { group: 'arms',  segs: ['upperArm', 'foreArm'],      text: 'Выпрямите руки в локтях', voice: 'Выпрямите руки' },
  headDown:  { group: 'neck',  segs: ['neck'],                     text: 'Голова провисает — смотрите в пол перед собой', voice: 'Голову в линию со спиной' },
  headUp:    { group: 'neck',  segs: ['neck'],                     text: 'Голова задрана — вытяните шею в линию со спиной', voice: 'Опустите взгляд' },
  bentKnees: { group: 'knees', segs: ['thigh', 'shin'],            text: 'Выпрямите колени — напрягите бёдра', voice: 'Выпрямите колени' },
};
const PRIORITY = ['sagHip', 'pikeHip', 'armsFwd', 'armsBack', 'bentArms', 'headDown', 'headUp', 'bentKnees'];

/**
 * @param {Array<{x:number,y:number,v:number}>} p  33 точки MediaPipe в пикселях
 * @param {{frameW:number, frameH:number, mode?:'auto'|'forearm'|'high', strict?:number}} o
 */
export function analyzePlank(p, o) {
  const k = o.strict ?? 1;
  const mode0 = o.mode ?? 'auto';
  if (!p || p.length < 29) return { detected: false, inPosition: false, issues: [] };

  const vis = (i) => (p[i] ? p[i].v ?? 0 : 0);
  const sideScore = (ids) => ids.reduce((s, i) => s + vis(i), 0);
  const L = [LM.SH_L, LM.EL_L, LM.HIP_L, LM.KN_L, LM.AN_L];
  const R = [LM.SH_R, LM.EL_R, LM.HIP_R, LM.KN_R, LM.AN_R];
  const left = sideScore(L) >= sideScore(R);
  const ids = left
    ? { S: LM.SH_L, E: LM.EL_L, W: LM.WR_L, H: LM.HIP_L, K: LM.KN_L, A: LM.AN_L, Ear: LM.EAR_L }
    : { S: LM.SH_R, E: LM.EL_R, W: LM.WR_R, H: LM.HIP_R, K: LM.KN_R, A: LM.AN_R, Ear: LM.EAR_R };

  const S = p[ids.S], H = p[ids.H], A = p[ids.A];
  if (vis(ids.S) < 0.45 || vis(ids.H) < 0.45 || vis(ids.A) < 0.35) {
    return { detected: false, inPosition: false, issues: [] };
  }
  const ok = (i) => vis(i) >= 0.4;
  const E = ok(ids.E) ? p[ids.E] : null;
  const W = ok(ids.W) ? p[ids.W] : null;
  const K = ok(ids.K) ? p[ids.K] : null;
  const Ear = ok(ids.Ear) ? p[ids.Ear] : null;

  const SA = vec(A, S);               // от стоп к плечу
  const bodyLen = len(SA);
  const horizDeg = Math.atan2(Math.abs(SA.y), Math.abs(SA.x)) / D2R;
  const minLen = 0.2 * Math.max(o.frameW, o.frameH);
  let inPosition = bodyLen >= minLen && horizDeg <= 35;
  if (inPosition && E && E.y < S.y - 0.03 * bodyLen) inPosition = false; // локоть выше плеча — не планка

  // Куда смотрит человек: +1 — голова справа в кадре, −1 — слева.
  const facing = SA.x >= 0 ? 1 : -1;

  // Нормаль «вверх» к оси тела
  const b = unit(SA);
  let up = { x: -b.y, y: b.x };
  if (up.y > 0) up = { x: -up.x, y: -up.y };

  const metrics = {};
  const issues = [];
  const push = (id, s) => issues.push({ id, sev: s, ...ISSUES[id] });

  // 1) Линия корпуса: плечо–таз–стопа
  const dev = dot(vec(S, H), up) / bodyLen; // >0 — таз выше линии
  metrics.hipDev = dev;
  metrics.hipAngle = angleAt(S, H, A);
  if (dev < 0) { const s = sev(-dev, BASE.hipSag, k); if (s) push('sagHip', s); }
  else { const s = sev(dev, BASE.hipPike, k); if (s) push('pikeHip', s); }

  // 2) Руки
  let mode = mode0;
  if (E && W) {
    metrics.elbowAngle = angleAt(S, E, W);
    if (mode0 === 'auto') mode = metrics.elbowAngle < 125 ? 'forearm' : 'high';
  } else if (mode0 === 'auto') mode = 'forearm';
  const T = mode === 'high' ? (W || E) : E;
  if (T) {
    const d = vec(S, T);
    if (d.y > 0.05 * bodyLen) {
      const tilt = Math.atan2(Math.abs(d.x), d.y) / D2R;
      metrics.armTilt = tilt;
      const s = sev(tilt, BASE.armTilt, k);
      if (s) push(d.x * facing > 0 ? 'armsFwd' : 'armsBack', s);
    }
  }
  if (mode === 'high' && E && W) {
    const s = sev(180 - metrics.elbowAngle, BASE.elbowDev, k);
    if (s) push('bentArms', s);
  }

  // 3) Шея: ухо относительно линии корпуса
  if (Ear) {
    const v = vec(S, Ear);
    if (len(v) > 0.03 * bodyLen) {
      const ang = Math.acos(Math.max(-1, Math.min(1, dot(unit(v), b)))) / D2R;
      const lifted = dot(v, up) > 0;
      metrics.neckAngle = lifted ? ang : -ang;
      const s = lifted ? sev(ang, BASE.neckLift, k) : sev(ang, BASE.neckDrop, k);
      if (s) push(lifted ? 'headUp' : 'headDown', s);
    }
  }

  // 4) Колени
  if (K) {
    metrics.kneeAngle = angleAt(H, K, A);
    const s = sev(180 - metrics.kneeAngle, BASE.kneeDev, k);
    if (s) push('bentKnees', s);
  }

  issues.sort((a, c) => c.sev - a.sev || PRIORITY.indexOf(a.id) - PRIORITY.indexOf(c.id));

  // Статус по группам для индикаторов
  const groups = { body: 'ok', arms: E || W ? 'ok' : 'na', neck: Ear ? 'ok' : 'na', knees: K ? 'ok' : 'na' };
  for (const i of issues) {
    if (groups[i.group] === 'bad') continue;
    groups[i.group] = i.sev === 2 ? 'bad' : 'warn';
  }

  return {
    detected: true, inPosition, side: left ? 'L' : 'R', facing, mode,
    metrics, issues, groups, bodyLen,
    pts: { S, E, W, H, K, A, Ear },
  };
}

/** Антидребезг: ошибка «включается», если держится onMs, и «гаснет» через offMs. */
export class IssueTracker {
  constructor(onMs = 650, offMs = 450) {
    this.onMs = onMs; this.offMs = offMs;
    this.seen = new Map();   // id → {since, last, sev, active}
  }
  /** @returns {Map<string, number>} активные ошибки id → серьёзность */
  update(issues, now) {
    const present = new Map(issues.map((i) => [i.id, i.sev]));
    for (const [id, s] of present) {
      const r = this.seen.get(id);
      if (!r || now - r.last >= this.offMs) this.seen.set(id, { since: now, last: now, sev: s, active: false });
      else { r.last = now; r.sev = s; }
    }
    const out = new Map();
    for (const [id, r] of this.seen) {
      if (!present.has(id) && now - r.last >= this.offMs) { this.seen.delete(id); continue; }
      if (present.has(id) && !r.active && now - r.since >= this.onMs) r.active = true;
      if (r.active) out.set(id, r.sev);
      // если ошибка пропала недавно, но ещё не «погасла» — оставляем как есть
    }
    return out;
  }
  reset() { this.seen.clear(); }
}

/** Накопление статистики за подход. */
export class SessionStats {
  constructor() { this.total = 0; this.clean = 0; this.warn = 0; this.bad = 0; this.perIssue = {}; }
  add(dt, active) {
    this.total += dt;
    let worst = 0;
    for (const [id, s] of active) { worst = Math.max(worst, s); this.perIssue[id] = (this.perIssue[id] || 0) + dt; }
    if (worst === 0) this.clean += dt; else if (worst === 1) this.warn += dt; else this.bad += dt;
  }
  get score() {
    if (this.total <= 0) return 0;
    return Math.round((100 * (this.clean + 0.6 * this.warn + 0.15 * this.bad)) / this.total);
  }
  get cleanShare() { return this.total > 0 ? this.clean / this.total : 0; }
  top(n = 3, minShare = 0.12) {
    return Object.entries(this.perIssue)
      .map(([id, seconds]) => ({ id, seconds, share: this.total ? seconds / this.total : 0 }))
      .filter((x) => x.share >= minShare)
      .sort((a, b) => b.seconds - a.seconds)
      .slice(0, n);
  }
}

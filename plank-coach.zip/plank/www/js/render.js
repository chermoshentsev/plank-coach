// Отрисовка видео и скелета на canvas.
export const COLORS = {
  ok: '#37F2A5', warn: '#FFB02E', bad: '#FF4D6D', idle: '#9FB0D6', line: 'rgba(255,255,255,0.55)',
};
const sevColor = (s) => (s >= 2 ? COLORS.bad : s === 1 ? COLORS.warn : COLORS.ok);

/** Преобразование координат кадра в координаты экрана (contain + зеркало). */
export function makeView(cw, ch, vw, vh, mirror) {
  const scale = Math.min(cw / vw, ch / vh);
  const ox = (cw - vw * scale) / 2, oy = (ch - vh * scale) / 2;
  return {
    cw, ch, vw, vh, scale, ox, oy, mirror,
    map: (p) => ({ x: mirror ? ox + (vw - p.x) * scale : ox + p.x * scale, y: oy + p.y * scale }),
  };
}

export function drawVideo(ctx, video, view) {
  const { cw, ch, vw, vh, scale, ox, oy, mirror } = view;
  ctx.fillStyle = '#05070f';
  ctx.fillRect(0, 0, cw, ch);
  if (!vw || !vh) return;
  ctx.save();
  if (mirror) { ctx.translate(cw, 0); ctx.scale(-1, 1); }
  const dx = mirror ? cw - (ox + vw * scale) : ox;
  ctx.drawImage(video, dx, oy, vw * scale, vh * scale);
  ctx.restore();
  ctx.fillStyle = 'rgba(5,8,20,0.28)';
  ctx.fillRect(0, 0, cw, ch);
}

function line(ctx, a, b, color, width, glow = true) {
  ctx.save();
  ctx.lineCap = 'round';
  ctx.strokeStyle = color;
  ctx.lineWidth = width;
  if (glow) { ctx.shadowColor = color; ctx.shadowBlur = 14; }
  ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke();
  ctx.restore();
}
function dot(ctx, p, color, r) {
  ctx.save();
  ctx.fillStyle = color;
  ctx.shadowColor = color; ctx.shadowBlur = 10;
  ctx.beginPath(); ctx.arc(p.x, p.y, r, 0, Math.PI * 2); ctx.fill();
  ctx.shadowBlur = 0;
  ctx.lineWidth = 2; ctx.strokeStyle = 'rgba(255,255,255,0.9)'; ctx.stroke();
  ctx.restore();
}

/**
 * @param res      результат analyzePlank (или null)
 * @param active   Map id→sev (после антидребезга)
 * @param issueDefs словарь ISSUES (для сегментов)
 */
export function drawSkeleton(ctx, view, res, active, issueDefs) {
  if (!res || !res.detected) return;
  const { S, E, W, H, K, A, Ear } = res.pts;
  const live = res.inPosition;
  const segSev = {};
  if (live) {
    for (const [id, s] of active) for (const seg of issueDefs[id].segs) segSev[seg] = Math.max(segSev[seg] || 0, s);
  }
  const col = (seg) => (live ? sevColor(segSev[seg] || 0) : COLORS.idle);
  const m = view.map;
  const w = Math.max(4, Math.min(9, view.scale * 7));

  // «Идеальная» прямая от стоп до плеча
  const a = m(A), s = m(S), h = m(H);
  if (live) {
    ctx.save();
    ctx.setLineDash([10, 10]);
    ctx.strokeStyle = COLORS.line; ctx.lineWidth = 2;
    const dx = s.x - a.x, dy = s.y - a.y, l = Math.hypot(dx, dy) || 1;
    const ext = 40;
    ctx.beginPath();
    ctx.moveTo(a.x - (dx / l) * ext, a.y - (dy / l) * ext);
    ctx.lineTo(s.x + (dx / l) * ext, s.y + (dy / l) * ext);
    ctx.stroke();
    ctx.restore();

    // Где таз должен быть и куда он «уехал»
    const hipSev = ['sagHip', 'pikeHip'].map((id) => active.get(id) || 0).reduce((x, y) => Math.max(x, y), 0);
    if (hipSev) {
      const dx2 = S.x - A.x, dy2 = S.y - A.y, l2 = Math.hypot(dx2, dy2) || 1;
      const t = ((H.x - A.x) * dx2 + (H.y - A.y) * dy2) / (l2 * l2);
      const P = m({ x: A.x + dx2 * t, y: A.y + dy2 * t });
      ctx.save();
      ctx.strokeStyle = sevColor(hipSev); ctx.lineWidth = 3; ctx.setLineDash([4, 5]);
      ctx.beginPath(); ctx.moveTo(h.x, h.y); ctx.lineTo(P.x, P.y); ctx.stroke();
      ctx.setLineDash([]);
      ctx.beginPath(); ctx.arc(P.x, P.y, 11, 0, Math.PI * 2); ctx.stroke();
      ctx.restore();
    }
  }

  if (Ear) line(ctx, s, m(Ear), col('neck'), w * 0.8);
  line(ctx, s, h, col('torso'), w);
  if (K) { line(ctx, h, m(K), col('thigh'), w); line(ctx, m(K), a, col('shin'), w); }
  else line(ctx, h, a, col('thigh'), w);
  if (E) { line(ctx, s, m(E), col('upperArm'), w * 0.9); if (W) line(ctx, m(E), m(W), col('foreArm'), w * 0.9); }

  const jc = (seg) => col(seg);
  dot(ctx, s, jc('torso'), w * 0.9);
  dot(ctx, h, jc('torso'), w * 0.9);
  if (K) dot(ctx, m(K), jc('thigh'), w * 0.8);
  dot(ctx, a, jc('shin'), w * 0.8);
  if (E) dot(ctx, m(E), jc('upperArm'), w * 0.8);
  if (W) dot(ctx, m(W), jc('foreArm'), w * 0.7);
  if (Ear) dot(ctx, m(Ear), jc('neck'), w * 0.7);
}
